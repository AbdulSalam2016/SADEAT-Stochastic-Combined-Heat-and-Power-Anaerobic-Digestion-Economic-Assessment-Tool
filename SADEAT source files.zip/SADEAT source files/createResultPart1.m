function [gui,data] = createResultPart1(resultsPart1,gui,data)
% http://uk.mathworks.com/help/matlab/ref/uitable-properties.html
% http://uk.mathworks.com/help/matlab/ref/uitable.html

gui.result1 = uitable(resultsPart1);

end
