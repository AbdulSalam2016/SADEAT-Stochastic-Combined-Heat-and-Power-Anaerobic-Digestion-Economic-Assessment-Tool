function onExit(src, ~,gui)
% User wants to quit out of the application
delete( gui.Window );

end % onExit